package com.springboot.inventoryproject.entity;


import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name="inventory_springboot")
public class Inventory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id")
    private int id;

    @Column(name="product_name")
    private String product_name;

    @Column(name="vendor_name")
    private String vendor_name;

    @Column(name="product_price")
    private float product_price;

    @Column(name="initial_quantity")
    private int initial_quantity;

    @Column(name="units_sold")
    private int units_sold;

    @Column(name="units_available")
    private int units_available;


}
