package com.springboot.inventoryproject.dao;

import com.springboot.inventoryproject.entity.Inventory;
import org.springframework.data.jpa.repository.JpaRepository;

public interface InventoryJpaRepo extends JpaRepository<Inventory, Integer> {
}
