package com.springboot.inventoryproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InventoryprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(InventoryprojectApplication.class, args);
	}

}
