DROP DATABASE  IF EXISTS `inventory_demo_db`;

CREATE DATABASE  IF NOT EXISTS `inventory_demo_db`;
USE `inventory_demo_db`;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `enabled` tinyint(1) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Inserting data for table `users`
--

INSERT INTO `users` 
VALUES 
('8080','{noop}8080',1);

--
-- Inserting data for table `users`
--

INSERT INTO `users` 
VALUES 
('john','{noop}test123',1),
('mary','{noop}test123',1),
('susan','{noop}test123',1);


--
-- Table structure for table `authorities`
--

DROP TABLE IF EXISTS `authorities`;
CREATE TABLE `authorities` (
  `username` varchar(50) NOT NULL,
  `authority` varchar(50) NOT NULL,
  UNIQUE KEY `authorities_idx_1` (`username`,`authority`),
  CONSTRAINT `authorities_ibfk_1` FOREIGN KEY (`username`) REFERENCES `users` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Inserting data for table `authorities`
--

INSERT INTO `authorities` 
VALUES 
('john','ROLE_EMPLOYEE'),
('mary','ROLE_EMPLOYEE'),
('mary','ROLE_MANAGER'),
('susan','ROLE_EMPLOYEE'),
('8080','ROLE_ADMIN');



DROP TABLE IF EXISTS `inventory_springboot`;

CREATE TABLE `inventory_springboot` (
  `id` int(1) NOT NULL AUTO_INCREMENT,
  `product_name` varchar(45) DEFAULT NULL,
  `vendor_name` varchar(45) DEFAULT NULL,
  `product_price` double DEFAULT NULL,
  `initial_quantity` smallint(5) DEFAULT NULL,
  `units_sold` smallint(5) DEFAULT NULL,
  `units_available` smallint(5) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

insert into 
inventory_springboot(product_name, 
vendor_name, 
product_price, 
initial_quantity, 
units_sold, 
units_available) 
values 
('12oz Dr. Pepper','Pepsi', 6.55, 50, 18, 22),
('SodaStream XL','SodaStream', 29.99, 40, 10, 30),
('Libby Vienna Sausages','Libby', 0.60, 150, 100, 50),
('Arnold Palmer Half&Half Sweet Tea','Arizona', 1.50, 80, 50, 30),
('Aquaphor Healing Ointment Advanced','Beiersof', 2.55, 100, 70, 30),
('Bellpoint Inc Pens 10pk','Bellpoint', 2.50, 200, 195, 5);
